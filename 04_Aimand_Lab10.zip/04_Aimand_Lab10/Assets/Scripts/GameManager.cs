﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;
    public Text ScoreText;
    public int score;

    private void Awake()
    {
        instance = this;
    }

    // Start is called before the first frame update
    void Start()
    {
        ScoreText.text = "Score : " + score;
    }

    public void ScoreUpdate()
    {
        score++;
        ScoreText.text = "Score : " + score;
    }
}
